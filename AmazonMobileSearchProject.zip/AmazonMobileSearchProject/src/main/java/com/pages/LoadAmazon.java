package com.pages;

import amazonSearch.BaseTestClass;

public class LoadAmazon extends BaseTestClass {
	public static void openUrl(String baseUrl) throws Exception
	{
		driver.get(baseUrl);
		Thread.sleep(3000);
		driver.manage().window().maximize();
		System.out.println("The current URL: "+driver.getCurrentUrl()+"\n");
		Thread.sleep(1000);TakeScreenshot("HomePageAmazon");
	}

}
