package com.pages;

import org.openqa.selenium.By;
import amazonSearch.BaseTestClass;

public class CountSortOptions extends BaseTestClass {
	public static void countSortOptions() throws Exception  {

		driver.findElement(By.cssSelector("#a-autoid-0-announce")).click();
		Thread.sleep(1000);TakeScreenshot("Dropdown");
		String t = driver.findElement(By.className("a-popover-inner")).getText();
		int n = t.split("\\n").length;
		if (n > 4) {
			System.out.println("Test 2");
			System.out.println("Validation Failed !");
			System.out.println("Dropdown options = " + n + ". Should be 4.");
			System.out.println();
		} else {
			System.out.println("Test 2");
			System.out.println("Validation Passed.");
			System.out.println();
		}
		
	}

}
