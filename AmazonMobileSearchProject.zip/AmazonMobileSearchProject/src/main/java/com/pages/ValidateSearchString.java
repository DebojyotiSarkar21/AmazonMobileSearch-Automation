package com.pages;

import org.openqa.selenium.By;

import amazonSearch.BaseTestClass;

public class ValidateSearchString extends BaseTestClass {

	public static void validateSearchString(String sendKeys) throws Exception {

		driver.findElement(By.id("twotabsearchtextbox")).sendKeys(sendKeys);
		driver.findElement(By.id("twotabsearchtextbox")).submit();
		Thread.sleep(3000);
		String resultCount = driver
				.findElement(
						By.cssSelector(".sg-col-14-of-20 > div:nth-child(1) > div:nth-child(1) > span:nth-child(1)"))
				.getText();
		if (resultCount.matches("\\d+-\\d+ of over \\d+,\\d+ results for")) {
			System.out.println("Test 1");
			System.out.println("Validation Passed !!!");
			System.out.println("Search results: " + resultCount + " mobile smartphones under 30000.");
			System.out.println();
		} else {
			System.out.println("Test 1");
			System.out.println("Validation Failed !");
			System.out.println(resultCount);
			System.out.println();
		}
		Thread.sleep(1000);TakeScreenshot("SearchString");

	}
}