package com.pages;

import org.openqa.selenium.By;

import amazonSearch.BaseTestClass;

public class ValidateRightOption extends BaseTestClass {
	public static void validateRightOption() throws Exception {

		driver.findElement(By.cssSelector("#s-result-sort-select_4")).click();
		Thread.sleep(1000);TakeScreenshot("Newest Arrival");
		String v = driver.findElement(By.cssSelector(".a-dropdown-prompt")).getText();
		if (v.equals("Newest Arrivals")) {
			System.out.println("Test 3");
			System.out.println("Validation Passed !!! ");
			System.out.println(v + " got selected correctly.");
			System.out.println();
		} else {
			System.out.println("Test 3");
			System.out.println("Validation Failed !");
			System.out.println(v + "got selected.");
			System.out.println();
		}
		
	}

}
