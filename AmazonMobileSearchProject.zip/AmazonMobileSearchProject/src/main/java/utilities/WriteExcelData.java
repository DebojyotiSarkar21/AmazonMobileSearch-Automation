package utilities;

import java.io.File;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WriteExcelData {
	
	public static void excelData()throws Exception {
		
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet();
		
		sheet.createRow(0);
		sheet.getRow(0).createCell(0).setCellValue("baseURL");
		sheet.getRow(0).createCell(1).setCellValue("https://www.amazon.in");
		
		sheet.createRow(1);
		sheet.getRow(1).createCell(0).setCellValue("Send Keys");
		sheet.getRow(1).createCell(1).setCellValue("mobile smartphone under 30000");
		
		
		File file = new File("ExcelData/testInput.xlsx");
		
		FileOutputStream fOS = new FileOutputStream(file);
		wb.write(fOS);
		wb.close();
		
	}
	
}
