package amazonSearch;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.pages.CountSortOptions;
import com.pages.LoadAmazon;
import com.pages.ValidateRightOption;
import com.pages.ValidateSearchString;
import utilities.WriteExcelData;

public class BaseTestClass {
	
	public static WebDriver driver;
	public static String browser="";
	
	//Method to invoke driver
	@Parameters("browserName")
	@BeforeTest
	public void createDriver(String browserName) throws Exception
    {
    	WriteExcelData.excelData();
		Thread.sleep(5000);
		System.out.println("\n\n=====================================================================\nCurrently, Test cases are being tested in "+browserName+"\n======================================================================\n");
    	
    	if(browserName.equalsIgnoreCase("chrome")) {
    		
    		
    		driver = new ChromeDriver();
    		browser=browserName;
    		
    	}
    	
    	else if(browserName.equalsIgnoreCase("firefox")) {
    		
    		
    		driver = new FirefoxDriver();
    		browser=browserName;
    		
    	}
    	
    	else if(browserName.equalsIgnoreCase("edge")) {
    		
    		
    		driver = new EdgeDriver();
    		browser=browserName;
    		
    	}

    }
    
	//Data Provider parses the data into the TestMethod
	@Test(dataProvider="testInput", priority =1)
	public void openAmazon(String baseUrl, String sendKeys) throws Exception {
		LoadAmazon.openUrl(baseUrl);

	}
	
	@Test(dataProvider="testInput",priority =2)
	public void validateSearchString(String baseUrl, String sendKeys) throws Exception {
		ValidateSearchString.validateSearchString(sendKeys);
		
	}
	
	@Test(priority =3)
	public void countOptions() throws Exception {
		CountSortOptions.countSortOptions();
		Thread.sleep(5000);
		}
	
	@Test(priority =4)
	public void rightOptionClick() throws Exception {
		ValidateRightOption.validateRightOption();
		Thread.sleep(5000);
		}
	
	
		//Close the browser
    	@AfterTest
    	public void closeBrowser()
    	{
    		driver.quit();
    		System.out.println("\n\n\n"+browser+" tests are over.\nxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
    	}
    	
    	//Take Input from Excel
    	@DataProvider(name="testInput")
		public Object[][] testData()throws IOException, FileNotFoundException {
			
			File file = new File("ExcelData/testInput.xlsx");
			FileInputStream fIS = new FileInputStream(file);
			XSSFWorkbook wb = new XSSFWorkbook(fIS);
			XSSFSheet sheet = wb.getSheetAt(0);
			
			String arr[][] = new String[2][2];
			
			for(int i=0;i<2;i++) {
				
				for(int j=0;j<2;j++) {
					
					arr[i][j]=sheet.getRow(i).getCell(j).getStringCellValue();
					
				}
			
			}
			
			wb.close();
			
			return new Object[][] {{arr[0][1], arr[1][1]}};
			
		}
    	
    	//Method to take Screenshots
    	public static void TakeScreenshot(String FileName) throws IOException {
			File File = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	        FileUtils.copyFile(File,new File("TestScreenshots/"+ FileName + "_" + browser + ".jpeg"));
	    }
    	

}

